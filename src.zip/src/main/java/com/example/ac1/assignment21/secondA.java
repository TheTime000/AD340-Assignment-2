package com.example.ac1.assignment21;

import android.R;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class secondA extends AppCompatActivity {
    private EditText Name;
    private TextView welcome;
    private Button BS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m2);

        MainActivity main = new MainActivity();
        welcome = (TextView) findViewById(R.id.textView);
        Name = (EditText) findViewById(R.id.editText1);
        BS = (Button) findViewById(R.id.button);
        Name.setText(main.name().getText().toString());
        welcome.setText("Thanks for signing up !");

        BS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
    }

    public void back(){
        Intent intent = new Intent (secondA.this, MainActivity.class );
        startActivity(intent);
    }
}
