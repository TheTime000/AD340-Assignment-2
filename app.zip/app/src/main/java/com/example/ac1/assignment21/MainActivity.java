package com.example.ac1.assignment21;

import android.R;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private Button Submit;
    private Button reset;
    private EditText Name;
    private EditText email;
    private EditText psw;
    private int ans;
    private EditText birth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m);

        Submit = (Button) findViewById(R.id.button);
        reset = (Button) findViewById(R.id.button2);
        Name = (EditText) findViewById(R.id.editText);
        email = (EditText) findViewById(R.id.editText2);
        psw = (EditText) findViewById(R.id.editText3);
        int ans = 0;
        birth = (EditText) findViewById(R.id.editText4);

        //setting caculate button and reset
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //validae... boolean....ue o jucy validaye hen move.
                validate(Name, email, psw, birth);
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //validae... boolean....ue o jucy validaye hen move.al
                validate(Name, email, psw, birth);

            }
        });
    }
    public void validate(EditText Name,EditText email,EditText psw,EditText birth){

        String date2 = birth.getText().toString();
        String date = date2.substring(6,9);
        int y = Integer.parseInt(date);
        ans = 2018-y;
        if(ans>=18 && psw.length()>=6){
            Intent intent = new Intent (MainActivity.this, secondA.class );
            startActivity(intent);
        }
        else {
            //one that says wrong
            Intent intent = new Intent (MainActivity.this, MainActivity.class );
            startActivity(intent);

        }
    }

    public EditText name(){

        return this.Name;
    }

}
